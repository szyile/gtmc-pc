'use strict'
module.exports = {
  NODE_ENV: '"production"',
  SERV_ADDR:'"https://iclub-pads.gtmc.com.cn/api"'
}
