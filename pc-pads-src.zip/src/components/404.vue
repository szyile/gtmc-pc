<template>
    <div id="err">
        <p class="page-container">抱歉，没有找到您的页面<span>（404）</span> </p>
    </div>
</template>

<style lang="less" scoped>
    .page-container {
        position: absolute;
        top: 50%;
        margin-top: -70px;
        width: 100%;
        height: 100px;
        line-height: 100px;
        font-size: 20px;
        text-align: center;
        span{
            font-size: 13px;
            color:grey;
        }
        
    }
</style>