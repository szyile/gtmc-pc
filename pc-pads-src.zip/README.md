# pc-fetchcar

> A Vue.js project

## Build Setup

``` bash
# install dependencies
cnpm/npm install

# serve with hot reload at localhost:8080
cnpm/npm run dev

# build for testMy with minification  我们的测试环境
cnpm/npm run testMy

# build for testGmtc with minification  广丰的测试环境
cnpm/npm run testGtmc

# build for production with minification  正式环境
cnpm/npm run build

# build for production and view the bundle analyzer report
cnpm/npm run build --report
```

For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).


1.【ID1004979】
【pc—订单一览】操作信息模块备注信息字段预约单号返回null,后台直接返回字段为NUll

2.订单号217275451466477568车主姓名是数字，后台返回数据就是数字

